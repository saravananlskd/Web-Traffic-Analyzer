from flask import Flask,render_template,request,flash,url_for,redirect
from flask_sqlalchemy import SQLAlchemy 
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/web_traffic_analyzer'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route('/ind1')
def ind1():
   return render_template("ind1.html")
@app.route('/index')
def index():
   return render_template("index.html")
@app.route('/about')
def about():
   return render_template("about.html")
@app.route('/contact')
def contact():
   return render_template("contact.html")  
@app.route('/empty')
def empty():
   return render_template("empty.html") 
@app.route('/admin')
def admin():
   return render_template("admin.html") 
@app.route('/cake')
def cake():
   return render_template("cake.html") 
@app.route('/snow')
def snow():
   return render_template("snow.html")
@app.route('/shop')
def shop():
   return render_template("shop.html")
@app.route('/team')
def team():
   return render_template("team.html")
@app.route('/experiance')
def experiance():
   return render_template("experiance.html")
@app.route('/register')
def register():
   return render_template("register.html")  
@app.route('/contact2')
def contact2():
   return render_template("contact2.html")    
@app.route('/checkout')
def checkout():
   return render_template("checkout.html")   
@app.route('/single')
def single():
   return render_template("single.html")        
class traffic(db.Model):
	id = db.Column('demo_id', db.Integer, primary_key = True)
	username = db.Column(db.String(100))
	password= db.Column(db.String(100))
	repeatpassword = db.Column(db.String(200)) 
	emailaddress = db.Column(db.String(100))
	def __init__(self, username, password, repeatpassword, emailaddress):
		self.username = username
		self.password = password
		self.repeatpassword = repeatpassword
		self.emailaddress = emailaddress
	@app.route('/login', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['username'] or not request.form['password'] or not request.form['repeatpassword']or not request.form['emailaddress']:
				flash('Please enter all the fields', 'error')
			else:
				demo = traffic(request.form['username'], request.form['password'], request.form['repeatpassword'], request.form['emailaddress'])
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('empty'))
		return render_template('index.html')
@app.route('/index', methods=['POST','GET'])
def login():
	if request.method=='GET':
		return render_template('index.html')
	username = request.form['username']
	password = request.form['password']
	demo=traffic.query.filter_by(username=username,password=password).first()
	if request.form['password'] == 'admin' and request.form['username'] == 'admin':
		return render_template("admin.html")
	if demo is None:
		return render_template("index.html")
	else:
		return render_template("empty.html")

class feedback(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	userid = db.Column(db.String(100))
	email = db.Column(db.String(100))
	comment = db.Column(db.String(100))
	def __init__(self, userid,email,comment):
		self.userid = userid
		self.email = email
		self.comment = comment
	@app.route('/contact', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['userid'] or not request.form['email'] or not request.form['comment']:
				flash('Please enter all the fields', 'error')
			else:
				feed = feedback(request.form['userid'], request.form['email'], request.form['comment'])
				db.session.add(feed)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('contact'))
		return render_template('contact.html')
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)

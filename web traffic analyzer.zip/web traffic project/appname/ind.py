from flask import Flask,render_template,request,flash,url_for,redirect
from flask_sqlalchemy import SQLAlchemy 
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/web_traffic_analyzer'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route('/emptypage')
def emptypage():
   return render_template("emptypage.html")
@app.route('/ind1')
def ind1():
   return render_template("ind1.html")
@app.route('/index')
def index():
   return render_template("index.html")
@app.route('/about')
def about():
   return render_template("about.html")
@app.route('/contact')
def contact():
   return render_template("contact.html")  
@app.route('/empty')
def empty():
   return render_template("empty.html") 
@app.route('/admin')
def admin():
   return render_template("admin.html") 
@app.route('/cake')
def cake():
   return render_template("cake.html") 
@app.route('/snow')
def snow():
   return render_template("snow.html")
@app.route('/shop')
def shop():
   return render_template("shop.html")
@app.route('/team')
def team():
   return render_template("team.html")
@app.route('/experiance')
def experiance():
   return render_template("experiance.html")
@app.route('/register')
def register():
   return render_template("register.html")  
@app.route('/contact2')
def contact2():
   return render_template("contact2.html")    
@app.route('/checkout')
def checkout():
   return render_template("checkout.html")   
@app.route('/single')
def single():
   return render_template("single.html")     
@app.route('/login1')
def login1():
   return render_template("login1.html")   
@app.route('/order')
def order():
   return render_template("order.html")      
@app.route('/doc_home')
def doc_home():
   return render_template("doc_home.html") 
@app.route('/deliver')
def deliver():
   return render_template("deliver.html")    
@app.route('/map')
def map():
   return render_template("map.html")   
@app.route('/location')
def location():
   return render_template("location.html")   
@app.route('/viewuser')
def viewuser():
   return render_template("viewuser.html",traffic=traffic.query.all())  
@app.route('/purchaserecord')
def purchaserecord():
   return render_template("purchaserecord.html",order=order.query.all())  
@app.route('/viewfeed')
def viewfeed():
   return render_template("viewfeed.html",feedback=feedback.query.all())                                                  
class traffic(db.Model):
	id = db.Column('demo_id', db.Integer, primary_key = True)
	username = db.Column(db.String(100))
	password= db.Column(db.String(100))
	repeatpassword = db.Column(db.String(200)) 
	emailaddress = db.Column(db.String(100))
	def __init__(self, username, password, repeatpassword, emailaddress):
		self.username = username
		self.password = password
		self.repeatpassword = repeatpassword
		self.emailaddress = emailaddress
	@app.route('/login', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['username'] or not request.form['password'] or not request.form['repeatpassword']or not request.form['emailaddress']:
				flash('Please enter all the fields', 'error')
			else:
				demo = traffic(request.form['username'], request.form['password'], request.form['repeatpassword'], request.form['emailaddress'])
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('empty'))
		return render_template('index.html')
@app.route('/index', methods=['POST','GET'])
def login():
	if request.method=='GET':
		return render_template('index.html')
	username = request.form['username']
	password = request.form['password']
	demo=traffic.query.filter_by(username=username,password=password).first()
	if request.form['password'] == 'admin' and request.form['username'] == 'admin':
		return render_template("admin.html")
	if demo is None:
		return render_template("index.html")
	else:
		return render_template("empty.html")

class feedback(db.Model):
	id = db.Column('feed_id', db.Integer, primary_key = True)
	userid = db.Column(db.String(100))
	email = db.Column(db.String(100))
	comment = db.Column(db.String(100))
	def __init__(self, userid,email,comment):
		self.userid = userid
		self.email = email
		self.comment = comment
	@app.route('/contact', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['userid'] or not request.form['email'] or not request.form['comment']:
				flash('Please enter all the fields', 'error')
			else:
				feed = feedback(request.form['userid'], request.form['email'], request.form['comment'])
				db.session.add(feed)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('contact'))
		return render_template('contact.html')
class order(db.Model):
	id = db.Column('ord_id', db.Integer, primary_key = True)
	username = db.Column(db.String(100))
	phonenumber = db.Column(db.String(100))
	address = db.Column(db.String(100))
	def __init__(self, username,phonenumber,address):
		self.username = username
		self.phonenumber = phonenumber
		self.address = address
	@app.route('/order', methods = ['GET', 'POST'])
	def new4():
		if request.method == 'POST':
			if not request.form['username'] or not request.form['phonenumber'] or not request.form['address']:
				flash('Please enter all the fields', 'error')
			else:
				ord = order(request.form['username'], request.form['phonenumber'], request.form['address'])
				db.session.add(ord)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('emptypage'))
		return render_template('order.html')
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
